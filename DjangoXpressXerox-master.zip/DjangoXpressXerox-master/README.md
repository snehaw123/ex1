
# XpressXerox

The web must be able to get documents from the customer, provide digital payment options and provide security to the documents transmitted by the user. The motivation behind the creation of this software is the outbreak of the coronavirus globally. This web app aims to minimize the use of physical contact. This web app will be freely available, as the cost to create this service is negligible. This web app will help the customer to upload the document from anywhere, also make payments from anywhere and also help minimize physical contact as per pandemic guidelines.

## Website

Click here to visit website [XpressXerox](http://xpressxerox.pythonanywhere.com/).



## Features

1. You can upload PDF, word files and images.
2. Documents are totally secure.
3. Easy to use platform.


## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.


## License
[MIT](https://choosealicense.com/licenses/mit/)
